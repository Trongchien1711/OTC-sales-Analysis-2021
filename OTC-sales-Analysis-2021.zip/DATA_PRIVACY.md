# Data Privacy Statement

Repo này chứa dữ liệu **sample** (ẩn danh) để minh họa.  
Không chứa dữ liệu gốc hoặc thông tin cá nhân (PII) thật.

Dữ liệu thật chỉ lưu tại `data/raw/` (được .gitignore).
Mọi yêu cầu truy cập dữ liệu thật sẽ được xem xét riêng.
