# Data Dictionary

## sales_2021_sample.csv
- order_id: Mã đơn hàng (string)
- customer_id: ID khách hàng (ẩn danh)
- product_id: Mã sản phẩm
- date: Ngày bán hàng (YYYY-MM-DD)
- quantity: Số lượng bán
- revenue: Doanh thu (VND)

## customers_sample.csv
- customer_id: ID khách hàng (ẩn danh)
- region: Miền (North/South/Central)
- city: Thành phố
- customer_type: Loyal/New/Churned
